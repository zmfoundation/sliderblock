<?php
/**
 * Plugin Name: SteinRein GB Blocks
 * Plugin URI: https://github.com/SteinRein/SteinRein-Gutenberg-Blocks
 * Description: Gutenberg Blocks for SteinRein
 * Author: Bastian Fießinger @steinrein
 * Author URI: https://github.com/SteinRein
 * Version: 1.0.0
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package SteinRein/Blocks
 */

if (! defined('ABSPATH')) {
	exit();
}

/**	 
 * Custom Block Category
 */
function sgb_custom_cats($cats){
	return array_merge(
		$cats,
		array(
			array(
				'slug'=> 'steinrein-blocks',
				'title'=> 'Steinrein GB Blocks'
			)
		)
	);
}
add_filter( 'block_categories', 'sgb_custom_cats', 10, 2 );

 /**
  * my_block_register_blocks
  *
  * @param  mixed $block_name
  * @param  mixed $options
  * @return void
  */
  
 function sgb_register_blocks( $block_name, $options= array() ){
	register_block_type(
		'sgb-block/' . $block_name,
		array_merge(
			array(
				'editor_script' => 'blocks-script',
				'editor_style'  => 'blocks-style',
				'script'        => 'blocks-front-script',
				'style'         => 'blocks-front-style'
			),
			$options
		)
	);
 }

/**
 * wt_blocks
 *
 * @return void
 */
function sgb_blocks(){
	/**
	 * Blocks Scripts
	 */
	wp_register_script( 'blocks-script', plugins_url( 'dist/editor.js', __FILE__ ), array( 'wp-blocks','wp-i18n', 'wp-editor', 'wp-components', 'wp-element', 'wp-blob' ));

	// Front End Script 
	wp_register_script( 'blocks-front-script', plugins_url( 'dist/script.js', __FILE__ ), array('jquery'));


	wp_register_style( 'blocks-style', plugins_url( 'dist/editor.css', __FILE__ ), array( 'wp-edit-blocks' ));

	// Front End Style
	wp_register_style( 'blocks-front-style', plugins_url( 'dist/style.css', __FILE__ ), array());

	/**
	 * Blocks Registration 
	 */
	// sgb_register_blocks( 'info-card' );
	// sgb_register_blocks( 'info-card-price' );
	sgb_register_blocks( 'service-block' );
	sgb_register_blocks( 'service-item' );
	sgb_register_blocks( 'service-slider' );
	sgb_register_blocks( 'service-slide' );

}
add_action( 'init', 'sgb_blocks' );

/**
 * External Libraries Enequeue 
*/
function sgb_external_scripts() {
	wp_enqueue_style(
		'tiny-slider',
		'//cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.3/tiny-slider.css'
	);

	wp_enqueue_script(
		'tiny-slider',
		'//cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js'
	);
}
add_action( 'enqueue_block_assets', 'sgb_external_scripts' );

/**
 * Plugin Support Link 
 */

function sgb_support_link( $links ) {
	$gts_settings = array(
		'<a href="'. esc_url( 'http://webackstop.com/' ) .'" target="_blank" style="color: green; font-weight: bold">Get Support</a>',
	);
	return array_merge( $gts_settings, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'sgb_support_link' );

