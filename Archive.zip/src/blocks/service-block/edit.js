import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InnerBlocks, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { PanelBody, ColorPalette, RangeControl, TextControl, Toolbar, IconButton } from '@wordpress/components';

class Edit extends Component {
	render() {
		const { className, attributes, setAttributes } = this.props;
		const { cols } = attributes;
		return (
			<Fragment>
				<BlockControls>

				</BlockControls>
				<InspectorControls>
					<PanelBody
						title="Service Columns"
						initialOpen={true}
					>
						<RangeControl
							label="Columns Number"
							value={cols}
							onChange={(cols) => this.props.setAttributes({ cols })}
							min={1}
							max={4}
						/>
					</PanelBody>

				</InspectorControls>
				<div className={`sgb_service_blocks_wrapper has-${cols}-cols`}>
					<InnerBlocks
						allowedBlocks={['sgb-block/service-item']}
						template={[
							['sgb-block/service-item'],
							['sgb-block/service-item'],
							['sgb-block/service-item']
						]}
					/>
				</div>
			</Fragment>
		)
	}
}

export default Edit;