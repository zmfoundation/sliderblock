import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { InnerBlocks, RichText } from '@wordpress/editor';

const attributes = {
	cols: {
		type: 'string',
		default: 3
	}
};

registerBlockType('sgb-block/service-block', {
	title: 'Service Block',
	description: 'Display Service Block',
	category: 'steinrein-blocks',
	icon: {
		src: <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24"><g><rect fill="none" height="24" width="24" /></g><g><g><path d="M16.24,11.51l1.57-1.57l-3.75-3.75l-1.57,1.57L8.35,3.63c-0.78-0.78-2.05-0.78-2.83,0l-1.9,1.9 c-0.78,0.78-0.78,2.05,0,2.83l4.13,4.13L3,17.25V21h3.75l4.76-4.76l4.13,4.13c0.95,0.95,2.23,0.6,2.83,0l1.9-1.9 c0.78-0.78,0.78-2.05,0-2.83L16.24,11.51z M9.18,11.07L5.04,6.94l1.89-1.9c0,0,0,0,0,0l1.27,1.27L7.02,7.5l1.41,1.41l1.19-1.19 l1.45,1.45L9.18,11.07z M17.06,18.96l-4.13-4.13l1.9-1.9l1.45,1.45l-1.19,1.19l1.41,1.41l1.19-1.19l1.27,1.27L17.06,18.96z" /><path d="M20.71,7.04c0.39-0.39,0.39-1.02,0-1.41l-2.34-2.34c-0.47-0.47-1.12-0.29-1.41,0l-1.83,1.83l3.75,3.75L20.71,7.04z" /></g><g /></g></svg>,
	},
	keywords: [
		'Service Box',
		'Service Block',
	],
	attributes,
	edit: Edit,
	save: ({ className, attributes }) => {
		const { cols } = attributes;
		return (
			<div className={`sgb_service_blocks_wrapper has-${cols}-cols`}>
				<InnerBlocks.Content />
			</div>
		)
	}
});