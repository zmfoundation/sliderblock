import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, RangeControl, TextControl, Toolbar, Button, ColorPalette } from '@wordpress/components';

const colors = [
    { name: 'red', color: '#f00' },
    { name: 'white', color: '#fff' },
    { name: 'blue', color: '#00f' },
    { name: 'black', color: '#000' },
];

const attributes = {
	serviceTitle: {
		type: 'string',
		default: 'Service Title'
	},
	url: {
		type: 'string'
	},
	alt: {
		type: 'string'
	},
	id: {
		type: 'number'
	},
	serviceLink: {
		type: 'string',
		default: '#'
    },
    serviceIcon: {
        type: 'string',
        default: null
    },
    innerPadding: {
        type: 'number',
        default: 5
    },
    serviceImageHeight: {
        type: 'number'
    },
    titleSize: {
        type: 'number',
        default: 20
    },
    titleColor: {
        type: 'string',
        default: '#000'
    },
    titleTopOffset: {
        type: 'number',
    }
}

registerBlockType('sgb-block/service-item', {
    title: __( 'Single Service Item' ),
    description: __( 'Service Item works as child block for Service Block' ),
    icon: {
        src: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="black" width="18px" height="18px"><path d="M12.75 3h-1.5L6.5 14h2.1l.9-2.2h5l.9 2.2h2.1L12.75 3zm-2.62 7L12 4.98 13.87 10h-3.74zm10.37 8l-3-3v2H5v2h12.5v2l3-3z"/><path d="M0 0h24v24H0z" fill="none"/></svg>
    },
    category: 'steinrein-blocks',
    supports: {
        reusable: false,
        html: false
    },
    attributes,
    edit: ({ className, attributes, setAttributes, isSelected }) => {
        const { serviceTitle, url, alt, id, serviceLink, serviceIcon, serviceImageHeight, innerPadding, titleSize, titleColor, titleTopOffset } = attributes;

        function serviceIconFunction( newIcon ) {
            setAttributes({ serviceIcon: newIcon.sizes.full.url  });
        }

        return (
            <Fragment>
                <BlockControls>
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
									{ isSelected && 
										<MediaUpload
											onSelect={ ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
											allowedTypes={ ['image'] }
											value={ id }
											render={ ( { open } ) => (
												<Button
													icon="edit"
													label="Edit Service Image"
													onClick={ open }
												/>
											) }
										/>
									}
								</MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
                <InspectorControls>
					<PanelBody
						title="Service Icon Setting"
						initialOpen= { false }
					>
						<MediaUpload
                            onSelect={ serviceIconFunction }
                            allowedTypes={ ['image'] }
                            value={ serviceIcon }
                            render={ ( { open } ) => (
                                <Button
                                    icon="upload"
                                    label="Upload Service Icon"
                                    onClick={ open }
                                    className="editor-media-placeholder__button is-default is-button is-large"
                                >
                                    UPLOAD SERVICE ICON
                                </Button>
                            ) }
                        />
                        <RangeControl
                            label={ __("Icon Inner Padding") }
                            value={ innerPadding }
                            onChange={ ( innerPadding ) => setAttributes( { innerPadding } ) }
                            min={ 0 }
                            max={ 100 }
                        />
					</PanelBody>
                    <PanelBody
                        title={ __("Service Image Height") }
                        initialOpen= { false }
                    >
                        <RangeControl
                            label={__( "Set Height" ) }
                            value={ serviceImageHeight }
                            onChange={ ( serviceImageHeight ) => setAttributes( { serviceImageHeight } ) }
                            min={ 50 }
                            max={ 1000 }
                        />
                    </PanelBody>
                    <PanelBody
                        title={ __( "Service Link Option" ) }
                        initialOpen= { false }
                    >
                        <TextControl
                            label={ __( "Service Link" ) }
                            value={ serviceLink }
                            onChange={ ( serviceLink ) => setAttributes( { serviceLink } ) }
                        />
                    </PanelBody> 
                    <PanelBody
                        initialOpen={ false }
                        title= { __( "Service Tittle Settings" ) }
                    >
                        <ColorPalette 
                            colors={ colors } 
                            value={ titleColor }
                            onChange={ ( titleColor ) => setAttributes( { titleColor } ) } 
                        />

                        <RangeControl
                            label={ __( "Font Size" ) }
                            value={ titleSize }
                            onChange={ ( titleSize ) => setAttributes( { titleSize } ) }
                            min={ 1 }
                            max={ 100 }
                        />

                        <RangeControl
                            label={ __( "Top Offset" ) }
                            value={ titleTopOffset }
                            onChange={ ( titleTopOffset ) => setAttributes( { titleTopOffset } ) }
                            min={ -50 }
                            max={ 100 }
                        />

                    </PanelBody>
				</InspectorControls>
                <div className="sgb_single_service_item">
                    <div className='service_image' style={{ height: serviceImageHeight }}>
                        { url ?
                                <>
                                    <a href={ serviceLink } target="_self">
                                        <img src={ url } alt={ alt } />
                                    </a>
                                    {
                                        isBlobURL( { url } ) && 
                                        <Spinner/>
                                    }
                                </>
                            : 
                                <MediaPlaceholder
                                    onSelect= { ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
                                    //onSelectURL={ (url)=> setAttributes( { url, id: null, alt: '' } ) }
                                    accept="image/*"
                                    allowedTypes={ ['image'] }
                                    labels = { { title: 'Service Image' } }
                                />
                        }
                        { serviceIcon && 
                            <div className="service_icon">
                                <img src={ serviceIcon } alt="service icon" style={{ padding: innerPadding }} />
                            </div>
                        }
                    </div>
                    <div className="service_title" style={{ marginTop: titleTopOffset }}>
                        <a href="#" target="_self" style={{ color: titleColor }}>
                            <RichText
                                tagName="h2"
                                className={ className }
                                value={ serviceTitle }
                                onChange={ ( serviceTitle ) => setAttributes( { serviceTitle } ) }
                                style={{ color: titleColor, fontSize: titleSize }}
                            />
                        </a>
                    </div>
                </div>
            </Fragment>
        )
    },
    save: ({ attributes, className }) => {
        const { serviceTitle, url, alt, id, serviceLink, serviceIcon, serviceImageHeight, innerPadding, titleColor, titleSize, titleTopOffset } = attributes;
        return (
            <div className="sgb_single_service_item">
                <div className='service_image' style={{ height: serviceImageHeight }}>
                    { url &&
                        <a href={ serviceLink } target="_blank" rel="noopener noreferrer">
                            <img src={ url } alt={ alt } className={ `wp-image-${id}` } />
                        </a>
                    }
                    { serviceIcon && 
                        <div className="service_icon">
                            <img src={ serviceIcon } alt="service icon" style={{ padding: innerPadding }} />
                        </div>
                    }
                </div>
                <div className="service_title" style={{ marginTop: titleTopOffset }}>
                    <a href={ serviceLink } target="_blank" rel="noopener noreferrer" style={{ color: titleColor }}>
                        <RichText.Content
                            tagName="h2"
                            className={ className }
                            value={ serviceTitle }
                            style={{ color: titleColor, fontSize: titleSize }}
                        />
                    </a>
                </div>
            </div>
        )
    }
})