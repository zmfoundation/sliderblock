import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InnerBlocks, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, ColorPalette, RangeControl, TextControl, Toolbar, IconButton } from '@wordpress/components';

const colors = [
	{
		name: "Dark Green",
		color: "#008255"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

class Edit extends Component {
    render() {
		const { className, attributes } = this.props;
		const { id, alt, url, btnText, siteInfo, logoText, rating, borderColor, borderWidth, titleSize, footerCols, btnUrl, btnPadding, btnRadius, btnTextColor, btnBgColor, logoLink, logoSize, subTextSize, subTextOffset } = attributes;
        return (
			<Fragment>
				<BlockControls>
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
                                    <MediaUpload
                                        onSelect={ ({ id, url, alt })=> this.props.setAttributes( { id, url, alt } ) }
                                        allowedTypes={ ['image'] }
                                        value={ id }
                                        render={ ( { open } ) => (
                                            <IconButton
                                                icon="edit"
                                                label="Edit Logo"
                                                onClick={ open }
                                            />
                                        ) }
                                    />
                                </MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
				<InspectorControls>
					<PanelBody
						title="Border Settings"
						initialOpen= { false }
					>
						<ColorPalette
							label="Border Color"
							colors={ colors }
							onChange={ ( borderColor ) => this.props.setAttributes( { borderColor } ) }
							value={ borderColor }
						/>
						<RangeControl
							label="Border Width"
							onChange={ ( borderWidth )=> this.props.setAttributes( { borderWidth } ) }
							value= { borderWidth }
							max= { 50 }
							min= { 0 }
						/>
					</PanelBody>
					<PanelBody
						title="Logo Setting"
						initialOpen= { false }
					>
						<RangeControl
							label="Text Logo Font Size"
							onChange={ ( titleSize )=> this.props.setAttributes( { titleSize } ) }
							value= { titleSize }
							max= { 100 }
							min= { 1 }
						/>
						<TextControl
							label="Image Logo Link"
							value={ logoLink }
							onChange={ ( logoLink ) => this.props.setAttributes( { logoLink } ) }
						/>
						<RangeControl
							label="Image Logo Size"
							onChange={ ( logoSize )=> this.props.setAttributes( { logoSize } ) }
							value= { logoSize }
							max= { 1000 }
							min= { 50 }
						/>
					</PanelBody>
					<PanelBody
						title="Sub Text Setting"
						initialOpen= { false }
					>
						<RangeControl
							label="Font Size"
							onChange={ ( subTextSize )=> this.props.setAttributes( { subTextSize } ) }
							value= { subTextSize }
							max= { 100 }
							min= { 1 }
						/>
						<RangeControl
							label="Top Offset"
							onChange={ ( subTextOffset )=> this.props.setAttributes( { subTextOffset } ) }
							value= { subTextOffset }
							max= { 100 }
							min= { -50 }
						/>
					</PanelBody>
					<PanelBody 
						title="Footer Content Columns"
						initialOpen= { false }
					>
						<RangeControl
							label="Columns Number"
							onChange={ ( footerCols )=> this.props.setAttributes( { footerCols } ) }
							value= { footerCols }
							max= { 4 }
							min= { 1 }
						/>
					</PanelBody>
					<PanelBody
						title="Button Link"
						initialOpen={ false }
					>
						<TextControl
							label="Button Link"
							value={ btnUrl }
							onChange={ ( btnUrl ) => this.props.setAttributes( { btnUrl } ) }
						/>
					</PanelBody>
					<PanelBody
						title="Button Styling"
						initialOpen={ false }
					>
						<RangeControl
							label="Padding"
							onChange={ ( btnPadding )=> this.props.setAttributes( { btnPadding } ) }
							value= { btnPadding }
							max= { 50 }
							min= { 0 }
						/>
						<RangeControl
							label="Border Radius"
							onChange={ ( btnRadius )=> this.props.setAttributes( { btnRadius } ) }
							value= { btnRadius }
							max= { 50 }
							min= { 0 }
						/>
					</PanelBody>
					<PanelBody
						title="Button Color Settings"
						initialOpen= { false }
					>
						<ColorPalette
							label=" Text Color "
							colors={ colors }
							onChange={ ( btnTextColor ) => this.props.setAttributes( { btnTextColor } ) }
							value={ btnTextColor }
						/>
						<ColorPalette
							label=" Text Background Color "
							colors={ colors }
							onChange={ ( btnBgColor ) => this.props.setAttributes( { btnBgColor } ) }
							value={ btnBgColor }
						/>
					</PanelBody>
				</InspectorControls>
				<div className="wt_info_box_container" style={ { borderColor: borderColor, borderWidth: borderWidth } }>
					<div className="wt_info_box_action_area">
						<div className="wt_site_logo">
							{ url ?
									<>
										<a href={ logoLink } target="_self">
											<img src={ url } alt={ alt } width={ logoSize } />
										</a>
										{
											isBlobURL( { url } ) && 
											<Spinner/>
										}
									</>
								: 
								<MediaPlaceholder
									onSelect= { ({ id, url, alt })=> this.props.setAttributes( { id, url, alt } ) }
									onSelectURL={ (url)=> this.props.setAttributes( { url, id: null, alt: '' } ) }
									accept="image/*"
									allowedTypes={ ['image'] }
								/>
							}
						</div>
						<a className="wt_action_btn" href={ btnUrl } target="_self" style={ { borderRadius: btnRadius, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 2*btnPadding, paddingRight: 2*btnPadding, color: btnTextColor, backgroundColor: btnBgColor } }>
							<RichText
								className={ className }
								value={ btnText }
								onChange={ ( btnText ) => this.props.setAttributes( { btnText } ) }
								formattingControls={ ['bold'] }
							/>
						</a>
						<div className="subtext" style={{ fontSize: subTextSize, marginTop: subTextOffset }}>
							<RichText
								className={ className }
								value={ siteInfo }
								onChange={ ( siteInfo ) => this.props.setAttributes( { siteInfo } ) }
								formattingControls={ ['bold','italic'] }
							/>
						</div>
					</div>
					<div className="wt_info_box_content_area">
						<div className="wt_content_head">
							<div className="wt_logo_title" style={ { fontSize: titleSize } }>
								<RichText
									value={ logoText }
									onChange={ ( logoText ) => this.props.setAttributes( { logoText } ) }
								/>
							</div>
							<div className="wt_header_rating">
								<RichText
									value={ rating }
									onChange={ ( rating ) => this.props.setAttributes( { rating } ) }
									formattingControls={ ['bold','italic'] }
								/>
							</div>
						</div>
						<div className={ `wt_content_footer has-${footerCols}-cols` }>
							<InnerBlocks
								allowedBlocks={ ['wt-block/info-card-price'] }
								template= {[
									["wt-block/info-card-price"],
									["wt-block/info-card-price"],
									["wt-block/info-card-price"]
								]}
							/>
						</div>
					</div>
				</div>
			</Fragment>
		)
    }
}

export default Edit;