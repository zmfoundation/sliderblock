import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, RangeControl, TextControl, Toolbar, Button, ColorPalette, RadioControl, Radio } from '@wordpress/components';

const colors = [
    { name: 'red', color: '#f00' },
    { name: 'white', color: '#fff' },
    { name: 'blue', color: '#00f' },
    { name: 'black', color: '#000' },
];

const attributes = {
	serviceTitle: {
		type: 'string',
		default: 'Service Title'
	},
	url: {
		type: 'string'
	},
	alt: {
		type: 'string'
	},
	id: {
		type: 'number'
	},
	serviceLink: {
		type: 'string',
		default: '#'
    },
    maxWidth: {
        type: 'number',
        default: 150
    },
    titleSize: {
        type: 'number',
        default: 20
    },
    titleColor: {
        type: 'string',
        default: '#000'
    },
    titleTopOffset: {
        type: 'number',
    },
    titleBottomOffset: {
        type: 'number'
    },
    titleAlign: {
        type: 'string',
        default: 'center'
    },
    description: {
        type: 'string',
        default: 'Here is a sample short description for the service. Just Pick up it.'
    },
    descSize: {
        type: 'number'
    },
    descColor: {
        type: 'string',
        default: '#000'
    },
    option: {
        type: 'string',
        default: 'center'
    }, 
}

registerBlockType('sgb-block/service-slide', {
    title: __( 'Single Service Slide' ),
    description: __( 'Service Slide works as child block for Service Slider' ),
    icon: {
        src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
    },
    category: 'steinrein-blocks',
    supports: {
        reusable: false,
        html: false
    },
    attributes,
    edit: ({ className, attributes, setAttributes, isSelected }) => {
        const { serviceTitle, url, alt, id, serviceLink, maxWidth, titleSize, titleColor, titleTopOffset, titleBottomOffset, descSize, descColor, description, option, titleAlign } = attributes;

        return (
            <Fragment>
                <BlockControls>
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
									{ isSelected && 
										<MediaUpload
											onSelect={ ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
											allowedTypes={ ['image'] }
											value={ id }
											render={ ( { open } ) => (
												<Button
													icon="edit"
													label="Edit Service Icon"
													onClick={ open }
												/>
											) }
										/>
									}
								</MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
                <InspectorControls>
                    <PanelBody
                        title={ __("Service Image Width") }
                        initialOpen= { false }
                    >
                        <RangeControl
                            label={__( "Set Max Width" ) }
                            value={ maxWidth }
                            onChange={ ( maxWidth ) => setAttributes( { maxWidth } ) }
                            min={ 1 }
                            max={ 1000 }
                        />
                    </PanelBody>
                    <PanelBody
                        title={ __( "Service Link Option" ) }
                        initialOpen= { false }
                    >
                        <TextControl
                            label={ __( "Service Link" ) }
                            value={ serviceLink }
                            onChange={ ( serviceLink ) => setAttributes( { serviceLink } ) }
                        />
                    </PanelBody> 
                    <PanelBody
                        initialOpen={ false }
                        title= { __( "Service Tittle Settings" ) }
                    >
                        <ColorPalette 
                            colors={ colors } 
                            value={ titleColor }
                            onChange={ ( titleColor ) => setAttributes( { titleColor } ) } 
                        />

                        <RangeControl
                            label={ __( "Font Size" ) }
                            value={ titleSize }
                            onChange={ ( titleSize ) => setAttributes( { titleSize } ) }
                            min={ 1 }
                            max={ 100 }
                        />
                        <RadioControl
                            label={ __( "Text Align" ) }
                            selected={ titleAlign }
                            options={ [
                                { label: 'Left', value: 'left' },
                                { label: 'Center', value: 'center' },
                                { label: 'Right', value: 'right' },
                            ] }
                            onChange={ ( titleAlign ) => setAttributes( { titleAlign } ) }
                        />
                        <RangeControl
                            label={ __( "Top Offset" ) }
                            value={ titleTopOffset }
                            onChange={ ( titleTopOffset ) => setAttributes( { titleTopOffset } ) }
                            min={ -100 }
                            max={ 100 }
                        />

                        <RangeControl
                            label={ __( "Bottom Offset" ) }
                            value={ titleBottomOffset }
                            onChange={ ( titleBottomOffset ) => setAttributes( { titleBottomOffset } ) }
                            min={ -100 }
                            max={ 100 }
                        />

                    </PanelBody>
                    <PanelBody
                        title={ __( "Description Settings" ) }
                        initialOpen= { false }
                    >
                        <ColorPalette 
                            colors={ colors } 
                            value={ descColor }
                            onChange={ ( descColor ) => setAttributes( { descColor } ) } 
                        />

                        <RangeControl
                            label={ __( "Font Size" ) }
                            value={ descSize }
                            onChange={ ( descSize ) => setAttributes( { descSize } ) }
                            min={ 1 }
                            max={ 100 }
                        />
                        <RadioControl
                            label={ __( "Text Align" ) }
                            selected={ option }
                            options={ [
                                { label: 'Left', value: 'left' },
                                { label: 'Center', value: 'center' },
                                { label: 'Right', value: 'right' },
                            ] }
                            onChange={ ( option ) => setAttributes( { option } ) }
                        />
                    </PanelBody>
				</InspectorControls>
                <div className="sgb_single_slide_item">
                    <div className='service_icon'>
                        { url ?
                                <>
                                    <a href={ serviceLink } target="_self">
                                        <img src={ url } alt={ alt } style={{ maxWidth: maxWidth }} />
                                    </a>
                                    {
                                        isBlobURL( { url } ) && 
                                        <Spinner/>
                                    }
                                </>
                            : 
                                <MediaPlaceholder
                                    onSelect= { ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
                                    //onSelectURL={ (url)=> setAttributes( { url, id: null, alt: '' } ) }
                                    accept="image/*"
                                    allowedTypes={ ['image'] }
                                    labels = { { title: 'Upload Service Icon' } }
                                />
                        }
                    </div>
                    <div className="service_title" style={{ marginTop: titleTopOffset, marginBottom: titleBottomOffset }}>
                        <a href="#" target="_self" style={{ color: titleColor }}>
                            <RichText
                                tagName="h2"
                                className={ className }
                                value={ serviceTitle }
                                onChange={ ( serviceTitle ) => setAttributes( { serviceTitle } ) }
                                style={{ color: titleColor, fontSize: titleSize, textAlign: titleAlign }}
                            />
                        </a>
                    </div>
                    <div className="service_desc">
                        <RichText
                            tagName="p"
                            className={ className }
                            value={ description }
                           onChange={ ( description ) => setAttributes( { description } ) }
                           style={{ color: descColor, fontSize: descSize, textAlign: option }}
                        />
                    </div>
                </div>
            </Fragment>
        )
    },
    save: ({ attributes, className }) => {
        const { serviceTitle, url, alt, id, serviceLink, maxWidth, titleColor, titleSize, titleTopOffset, descColor, descSize, description, titleBottomOffset, option, titleAlign } = attributes;
        return (
            <div className="sgb_single_slide_item">
                <div className='service_icon'>
                    { url &&
                        <a href={ serviceLink } target="_blank" rel="noopener noreferrer">
                            <img src={ url } alt={ alt }  style={{ maxWidth: maxWidth }} className={ `wp-image-${id}` } />
                        </a>
                    }
                </div>
                <div className="service_title" style={{ marginTop: titleTopOffset, marginBottom: titleBottomOffset }}>
                    <a href={ serviceLink } target="_blank" rel="noopener noreferrer" style={{ color: titleColor }}>
                        <RichText.Content
                            tagName="h2"
                            className={ className }
                            value={ serviceTitle }
                            style={{ color: titleColor, fontSize: titleSize, textAlign: titleAlign }}
                        />
                    </a>
                </div>
                <div className="service_desc">
                        <RichText.Content
                            tagName="p"
                            className={ className }
                            value={ description }
                           style={{ color: descColor, fontSize: descSize, textAlign: option }}
                        />
                    </div>
            </div>
        )
    }
})