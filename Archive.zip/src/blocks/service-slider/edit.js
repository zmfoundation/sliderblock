import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InnerBlocks, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { PanelBody, ColorPalette, RangeControl, TextControl, Toolbar, IconButton } from '@wordpress/components';

class Edit extends Component {
	render() {
		const { className, attributes, setAttributes } = this.props;
		const { items } = attributes;
		return (
			<Fragment>
				<InspectorControls>
					<PanelBody
						title="Slider Items"
						initialOpen={true}
					>
						<RangeControl
							label="Items Per Page"
							value={items}
							onChange={(items) => this.props.setAttributes({ items })}
							min={1}
							max={6}
						/>
					</PanelBody>

				</InspectorControls>
				<div className="sgb_service_sliders_wrapper">
					<InnerBlocks
						allowedBlocks={['sgb-block/service-slide']}
						template={[
							['sgb-block/service-slide'],
							['sgb-block/service-slide'],
							['sgb-block/service-slide']
						]}
					/>
				</div>
			</Fragment>
		)
	}
}

export default Edit;