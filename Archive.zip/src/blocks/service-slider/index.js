import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { InnerBlocks } from '@wordpress/editor';

const attributes = {
	items: {
		type: 'string',
		default: 3
	}
};

registerBlockType('sgb-block/service-slider', {
	title: __( 'Service Slider' ),
	description: __( 'Display Service Block in Sliding Manner' ),
	category: 'steinrein-blocks',
	icon: {
		src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 6.54v10.91c-2.6-.77-5.28-1.16-8-1.16-2.72 0-5.4.39-8 1.16V6.54c2.6.77 5.28 1.16 8 1.16 2.72.01 5.4-.38 8-1.16M21.43 4c-.1 0-.2.02-.31.06C18.18 5.16 15.09 5.7 12 5.7c-3.09 0-6.18-.55-9.12-1.64-.11-.04-.22-.06-.31-.06-.34 0-.57.23-.57.63v14.75c0 .39.23.62.57.62.1 0 .2-.02.31-.06 2.94-1.1 6.03-1.64 9.12-1.64 3.09 0 6.18.55 9.12 1.64.11.04.21.06.31.06.33 0 .57-.23.57-.63V4.63c0-.4-.24-.63-.57-.63z"/></svg>,
	},
	keywords: [
		'Service Box',
		'Service Block',
		'Service Slider',
	],
	attributes,
	edit: Edit,
	save: ({ className, attributes }) => {
		const { items } = attributes;
		return (
			<div className="sgb_service_sliders_wrapper">
				<InnerBlocks.Content />
			</div>
		)
	}
});