// import './blocks/info-card';
import './blocks/service-block';
import './blocks/service-slider';