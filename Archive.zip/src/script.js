// import './blocks/info-card/script';
import './blocks/service-block/script';
import './blocks/service-slider/script';